# Ubuntu Font
This module is a simple way to apply Ubuntu font systemlessly. 

## Source Code
- Module [GitHub](https://github.com/gloeyisk/Ubuntu-Font)
